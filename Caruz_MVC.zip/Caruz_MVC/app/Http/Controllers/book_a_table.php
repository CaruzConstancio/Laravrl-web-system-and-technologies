<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class book_a_table extends Controller
{
  public function store(Request $request){

    $book_a_table->addP_message($_POST['name'], 'Name');
    $book_a_table->addP_message($_POST['email'], 'Email');
    $book_a_table->addP_message($_POST['phone'], 'Phone');
    $book_a_table->addP_message($_POST['date'], 'Date');
    $book_a_table->addP_message($_POST['time'], 'Time');
    $book_a_table->addP_message($_POST['number_of_people'], 'Number of people');
    $book_a_table->addP_message($_POST['message'], 'Message');

    $book_a_table->send();
  }
}
